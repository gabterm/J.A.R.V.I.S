# JARVIS — versão nativa (PySide6)

Isto substitui `jarvis-hud.html` + `style.css` + `main.js` por uma janela
Qt de verdade. Não há mais navegador, servidor HTTP/websocket, HTML,
CSS ou JS — tudo é desenhado com widgets Qt e `QPainter`.

A lógica de negócio do JARVIS (`main.py`, `tools/tools.py`: memória,
extração de fatos, loop de tool calling, ferramentas) **não foi
alterada**. Só troquei a camada de transporte: onde antes existia
`tools/ui_bridge.py` fazendo um servidor websocket, agora existe um
`tools/ui_bridge.py` baseado em sinais Qt, com a mesma API pública
(`broadcast`, `mensagens_entrada`, `acoes_entrada`, `jarvis_falando`,
`start_server_in_background`). Por isso `main.py` e `tools/tools.py`
não precisaram mudar uma linha.

## Como rodar

```bash
pip install -r requirements.txt
# copie seu .env (OPENAI_API_KEY) e assets/memory.json (se já tiver) pra cá
python run_native.py
```

## O que fazer antes de usar de verdade

Eu só recebi 5 arquivos (`main.py`, `tools.py`, `jarvis-hud.html`,
`style.css`, `main.js`). O projeto original também importa outros
módulos que não foram enviados — `tools/voice.py`, `tools/jarvis_sounds.py`,
`tools/mic_listener.py`, `tools/whatsapp_agent.py`, `tools/web_agent.py`.

Criei **stubs** desses arquivos (marcados com `STUB` no topo) só para o
app rodar de ponta a ponta sem `ImportError`. Eles não fazem nada de
real — TTS só imprime no console, microfone não escuta nada,
WhatsApp/navegador retornam "não implementado". **Copie os arquivos
originais desses módulos do seu projeto por cima destes stubs** antes
de usar de verdade. Como mantive os mesmos nomes de função, a troca é
direta.

Também copie:
- seu `.env` com `OPENAI_API_KEY`
- `assets/memory.json`, se já tiver histórico salvo
- ajuste `assets/prompt.txt` (coloquei um genérico) se você tinha um prompt de sistema customizado

## O que já está portado (nativo, sem HTML/CSS/JS)

- Janela principal (`gui/main_window.py`), com layout equivalente ao HUD:
  barra superior (status/uptime/usuário), painel de terminal/chat,
  painel de logs com filtro por nível, barra de comando com microfone.
- Relógio/radar central (`gui/widgets/clock_widget.py`) — desenhado do
  zero com `QPainter` (anéis, ticks, sweep de radar, ponteiro de segundos),
  não é uma captura de tela do CSS original, é uma releitura nativa.
- 4 temas de cor (ciano/âmbar/violeta/vermelho), mesma paleta do
  `style.css`, aplicados via QSS (`gui/theme.py`).
- Notificações toast, cards simples de clima e notícias, preview de
  screenshot de navegação (mesmo conceito do HUD: o `web_agent` manda
  uma imagem, a UI só exibe — não é um navegador embutido).
- Bridge de eventos 1:1 com os tipos que o backend já manda (`log`,
  `status`, `event`, `notification`, `tool_exec`, `tool_result`,
  `weather`, `news_board`, `browser_screenshot`, `mic_state` etc).

## O que ficou de fora nesta primeira versão

O HUD original tem dois recursos visuais bem específicos que decidi
**não** tentar recriar de cara, porque são os mais caros em esforço e
os que trazem menos ganho de robustez (valem uma rodada própria):

1. **Quadro de raciocínio** (`reasoning_board`/`reasoning_frame`) — o
   grafo de nós conectados que o HUD desenhava em SVG. Hoje isso só
   aparece como uma linha no painel de logs.
2. **Simulação física** (`simulation_board`/`simulation_scene`/`simulation_frame`)
   — a cena animada com objetos físicos. Mesma coisa: só loga que foi
   chamada.

Também simplifiquei o painel de mídia com iframe (vídeo/áudio embutido)
— isso, se for necessário de verdade, dá pra fazer com
`QtMultimedia`/`QWebEngineView`, mas não veio nesta primeira entrega.

Se quiser, na próxima rodada eu porto o quadro de raciocínio e a
simulação para `QPainter` também (é factível — só é trabalho de
geometria/animação equivalente ao que fiz no relógio).

## Estrutura

```
jarvis_native/
  main.py                  # lógica original do JARVIS, inalterada
  run_native.py             # novo entrypoint: sobe a janela Qt + thread do backend
  assets/prompt.txt         # prompt de sistema (ajuste o seu)
  tools/
    tools.py                # ferramentas do LLM, inalterado
    ui_bridge.py             # NOVO: bridge Qt no lugar do servidor websocket
    voice.py                 # STUB — troque pelo original
    jarvis_sounds.py          # STUB — troque pelo original
    mic_listener.py            # STUB — troque pelo original
    whatsapp_agent.py           # STUB — troque pelo original
    web_agent.py                  # STUB — troque pelo original
  gui/
    main_window.py            # janela principal
    theme.py                   # paletas de cor + QSS
    widgets/
      clock_widget.py           # relógio/radar em QPainter
      terminal_panel.py
      logs_panel.py
      cmd_bar.py
      notification.py
```
