"""
Paleta de cores e QSS. Os valores de cor são os mesmos do
style.css original (:root e body.theme-*), só reescritos como
folha de estilo Qt em vez de CSS variables.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    bg: str
    bg2: str
    line: str
    line_strong: str
    cyan: str
    warn: str
    text: str
    text_dim: str


PALETTES = {
    "cyan":   Palette("#040c11", "#071319", "#12313d", "#1c4a59", "#7fd9ff", "#ff5b7a", "#e6f7ff", "#6c96a6"),
    "amber":  Palette("#040c11", "#071319", "#3d2f12", "#59461c", "#ffb45b", "#ff5b7a", "#e6f7ff", "#6c96a6"),
    "violet": Palette("#040c11", "#071319", "#241c3d", "#372a59", "#b98bff", "#ff5b7a", "#e6f7ff", "#6c96a6"),
    "red":    Palette("#040c11", "#071319", "#3d1216", "#591c22", "#ff5b6a", "#ff5b7a", "#e6f7ff", "#6c96a6"),
}

MONO_FONT = "JetBrains Mono"
DISPLAY_FONT = "Orbitron"


def build_qss(palette: Palette) -> str:
    return f"""
    QMainWindow, QWidget {{
        background-color: {palette.bg};
        color: {palette.text};
        font-family: '{MONO_FONT}';
    }}

    #TopBar {{
        background-color: {palette.bg2};
        border: 1px solid {palette.line_strong};
    }}
    #TopBar QLabel {{ color: {palette.text_dim}; font-size: 11px; }}
    #TopBar QLabel[role="value"] {{ color: {palette.text}; }}
    #TopBar QLabel[role="brand"] {{
        color: {palette.cyan}; font-family: '{DISPLAY_FONT}';
        font-weight: 700; font-size: 13px;
    }}
    #TopBar QLabel[role="ok"] {{ color: {palette.cyan}; }}
    #TopBar QLabel[role="offline"] {{ color: {palette.warn}; }}

    QFrame#Panel {{
        background-color: rgba(7, 19, 25, 180);
        border: 1px solid {palette.line_strong};
    }}
    QLabel[role="panel-title"] {{
        color: {palette.cyan}; font-family: '{DISPLAY_FONT}';
        font-size: 11px; letter-spacing: 1px; padding: 4px;
        border-bottom: 1px solid {palette.line};
    }}

    QPlainTextEdit#Terminal {{
        background: transparent; border: none;
        color: {palette.text}; font-size: 12px;
    }}

    QListWidget#Logs {{
        background: transparent; border: none; font-size: 11px;
    }}
    QListWidget#Logs::item {{ padding: 2px 6px; }}

    QPushButton.filter {{
        background: transparent; color: {palette.text_dim};
        border: 1px solid {palette.line}; padding: 2px 8px; font-size: 10px;
    }}
    QPushButton.filter:checked {{
        color: {palette.cyan}; border-color: {palette.cyan};
    }}

    QFrame#CmdBar {{
        background-color: {palette.bg2}; border: 1px solid {palette.line_strong};
    }}
    QTextEdit#CmdInput {{
        background: transparent; border: none; color: {palette.text};
        font-size: 13px;
    }}
    QPushButton#SendBtn, QPushButton#MicBtn {{
        background: transparent; color: {palette.cyan};
        border: 1px solid {palette.line_strong};
        border-radius: 4px; min-width: 28px; min-height: 28px;
    }}
    QPushButton#MicBtn[muted="true"] {{ color: {palette.warn}; }}
    QPushButton#SendBtn:hover, QPushButton#MicBtn:hover {{ border-color: {palette.cyan}; }}

    QFrame#SettingsDrawer {{
        background-color: rgba(4,12,17,235);
        border: 1px solid {palette.line_strong};
    }}

    QToolTip {{
        background-color: {palette.bg2}; color: {palette.text};
        border: 1px solid {palette.line_strong};
    }}
    """
