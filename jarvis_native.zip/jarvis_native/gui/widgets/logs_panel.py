from datetime import datetime

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QPushButton, QButtonGroup,
)

from gui.theme import PALETTES

LEVEL_LABEL = {"all": "TODOS", "info": "INFO", "warn": "AVISO", "error": "ERRO"}


class LogsPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self._theme = "cyan"
        self._events = []  # [(level, text, timestamp)]
        self._filter = "all"

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        header = QHBoxLayout()
        title = QLabel("LOGS")
        title.setProperty("role", "panel-title")
        header.addWidget(title, 1)
        self.count_label = QLabel("0")
        self.count_label.setProperty("role", "panel-title")
        header.addWidget(self.count_label)
        layout.addLayout(header)

        toolbar = QHBoxLayout()
        self.filter_group = QButtonGroup(self)
        self.filter_group.setExclusive(True)
        for level, label in LEVEL_LABEL.items():
            btn = QPushButton(label)
            btn.setProperty("class", "filter")
            btn.setCheckable(True)
            btn.setChecked(level == "all")
            btn.clicked.connect(lambda _checked, lvl=level: self._set_filter(lvl))
            self.filter_group.addButton(btn)
            toolbar.addWidget(btn)
        toolbar.addStretch(1)
        layout.addLayout(toolbar)

        self.list_widget = QListWidget()
        self.list_widget.setObjectName("Logs")
        self.list_widget.setFrameShape(QFrame.NoFrame)
        layout.addWidget(self.list_widget, 1)

    def set_theme(self, theme_name: str):
        self._theme = theme_name if theme_name in PALETTES else "cyan"
        self._render()

    def _set_filter(self, level: str):
        self._filter = level
        self._render()

    def add_event(self, level: str, text: str):
        level = level if level in ("info", "warn", "error") else "info"
        self._events.append((level, text, datetime.now().strftime("%H:%M:%S")))
        self.count_label.setText(str(len(self._events)))
        self._render()

    def _render(self):
        palette = PALETTES[self._theme]
        color_map = {
            "info": palette.text_dim,
            "warn": palette.cyan,
            "error": palette.warn,
        }
        self.list_widget.clear()
        for level, text, ts in self._events:
            if self._filter != "all" and level != self._filter:
                continue
            item = QListWidgetItem(f"[{ts}] {text}")
            from PySide6.QtGui import QColor
            item.setForeground(QColor(color_map[level]))
            self.list_widget.addItem(item)
        self.list_widget.scrollToBottom()
