from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QFrame, QHBoxLayout, QTextEdit, QPushButton


class _CmdInput(QTextEdit):
    """QTextEdit que envia com Enter e quebra linha com Shift+Enter."""

    submitted = Signal(str)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not (
            event.modifiers() & Qt.ShiftModifier
        ):
            text = self.toPlainText().strip()
            if text:
                self.submitted.emit(text)
                self.clear()
            return
        super().keyPressEvent(event)


class CmdBar(QFrame):
    message_sent = Signal(str)
    mic_toggled = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("CmdBar")
        self._mic_ativo = True

        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)

        self.mic_btn = QPushButton("🎙")
        self.mic_btn.setObjectName("MicBtn")
        self.mic_btn.setToolTip("Microfone ligado — clique para desligar")
        self.mic_btn.clicked.connect(self._toggle_mic)
        layout.addWidget(self.mic_btn)

        self.input = _CmdInput()
        self.input.setObjectName("CmdInput")
        self.input.setFixedHeight(34)
        self.input.setFrameShape(QFrame.NoFrame)
        self.input.submitted.connect(self._on_submit)
        layout.addWidget(self.input, 1)

        self.send_btn = QPushButton(">")
        self.send_btn.setObjectName("SendBtn")
        self.send_btn.clicked.connect(
            lambda: self._on_submit(self.input.toPlainText().strip())
        )
        layout.addWidget(self.send_btn)

    def _on_submit(self, text: str):
        if not text:
            return
        self.input.clear()
        self.message_sent.emit(text)

    def _toggle_mic(self):
        self._mic_ativo = not self._mic_ativo
        self.mic_btn.setProperty("muted", not self._mic_ativo)
        self.mic_btn.setToolTip(
            "Microfone ligado — clique para desligar"
            if self._mic_ativo
            else "Microfone desligado — clique para ligar"
        )
        self.style().unpolish(self.mic_btn)
        self.style().polish(self.mic_btn)
        self.mic_toggled.emit(self._mic_ativo)

    def set_mic_state(self, ativo: bool):
        self._mic_ativo = ativo
        self.mic_btn.setProperty("muted", not ativo)
        self.style().unpolish(self.mic_btn)
        self.style().polish(self.mic_btn)
