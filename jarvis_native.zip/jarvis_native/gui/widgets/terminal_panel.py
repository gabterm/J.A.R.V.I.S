from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QPlainTextEdit

from gui.theme import PALETTES

ROLE_PREFIX = {
    "user": "&gt;&gt;",
    "jarvis": "J.A.R.V.I.S.",
    "system": "SYS",
}


class TerminalPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self._theme = "cyan"

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        title = QLabel("DIRECT ACCESS")
        title.setProperty("role", "panel-title")
        layout.addWidget(title)

        self.output = QPlainTextEdit()
        self.output.setObjectName("Terminal")
        self.output.setReadOnly(True)
        self.output.setFrameShape(QFrame.NoFrame)
        layout.addWidget(self.output, 1)

    def set_theme(self, theme_name: str):
        self._theme = theme_name if theme_name in PALETTES else "cyan"

    def add_line(self, role: str, text: str):
        palette = PALETTES[self._theme]
        color = {
            "user": palette.text,
            "jarvis": palette.cyan,
            "system": palette.text_dim,
        }.get(role, palette.text)
        prefix = ROLE_PREFIX.get(role, role.upper())
        safe_text = (
            text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        )
        self.output.appendHtml(
            f'<span style="color:{color};">'
            f'<b>{prefix}</b> {safe_text}</span>'
        )
        self.output.verticalScrollBar().setValue(
            self.output.verticalScrollBar().maximum()
        )

    def clear(self):
        self.output.clear()
