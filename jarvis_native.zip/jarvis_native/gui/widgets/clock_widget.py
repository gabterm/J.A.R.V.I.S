"""
Equivalente nativo do `.clock-stage` do HUD original: anéis
concêntricos, ponteiro de segundos, sweep de radar e o horário no
centro. Tudo desenhado com QPainter — sem HTML, sem CSS, sem SVG.

Estados (mesma semântica do `setEstado()` do main.js):
    idle | thinking | speaking | offline
"""

import math
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, QRectF
from PySide6.QtGui import QPainter, QColor, QPen, QFont
from PySide6.QtWidgets import QWidget

from gui.theme import PALETTES, DISPLAY_FONT, MONO_FONT


class ClockRadarWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._theme = "cyan"
        self._state = "idle"
        self._sweep_deg = 0.0
        self.setMinimumSize(260, 260)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(40)  # ~25 fps é suficiente para o sweep

    def set_theme(self, theme_name: str):
        self._theme = theme_name if theme_name in PALETTES else "cyan"
        self.update()

    def set_state(self, state: str):
        self._state = state
        self.update()

    def _tick(self):
        speed = {"idle": 0.6, "thinking": 3.2, "speaking": 1.8, "offline": 0.0}
        self._sweep_deg = (self._sweep_deg + speed.get(self._state, 0.6)) % 360
        self.update()

    def paintEvent(self, event):
        palette = PALETTES[self._theme]
        cyan = QColor(palette.cyan)
        warn = QColor(palette.warn)
        active_color = warn if self._state == "offline" else cyan

        w, h = self.width(), self.height()
        side = min(w, h) - 10
        rect = QRectF((w - side) / 2, (h - side) / 2, side, side)
        center = rect.center()
        radius = side / 2

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        # halo de fundo
        p.setPen(Qt.NoPen)
        halo = QColor(active_color)
        halo.setAlpha(18)
        p.setBrush(halo)
        p.drawEllipse(center, radius * 0.98, radius * 0.98)

        # anéis concêntricos
        for i, (frac, alpha, width_px) in enumerate([
            (1.0, 60, 1.2), (0.86, 90, 2.0), (0.7, 40, 1.0),
        ]):
            pen = QPen(active_color)
            c = QColor(active_color)
            c.setAlpha(alpha)
            pen.setColor(c)
            pen.setWidthF(width_px)
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            r = radius * frac
            p.drawEllipse(center, r, r)

        # marcas de minuto (ticks)
        pen = QPen(active_color)
        tick_color = QColor(active_color)
        tick_color.setAlpha(120)
        pen.setColor(tick_color)
        pen.setWidthF(1.0)
        p.setPen(pen)
        for i in range(60):
            ang = math.radians(i * 6 - 90)
            r_out = radius * 0.86
            r_in = radius * (0.80 if i % 5 == 0 else 0.83)
            x1 = center.x() + r_out * math.cos(ang)
            y1 = center.y() + r_out * math.sin(ang)
            x2 = center.x() + r_in * math.cos(ang)
            y2 = center.y() + r_in * math.sin(ang)
            p.drawLine(int(x1), int(y1), int(x2), int(y2))

        # sweep de radar (arco semi-transparente girando)
        p.setPen(Qt.NoPen)
        sweep_color = QColor(active_color)
        sweep_color.setAlpha(50 if self._state != "offline" else 20)
        p.setBrush(sweep_color)
        sweep_rect = QRectF(center.x() - radius * 0.86, center.y() - radius * 0.86,
                             radius * 1.72, radius * 1.72)
        p.drawPie(sweep_rect, int(-self._sweep_deg * 16), int(-28 * 16))

        # ponteiro de segundos
        now = datetime.now()
        sec_ang = math.radians(now.second * 6 - 90)
        pen = QPen(active_color)
        pen.setWidthF(2.0)
        p.setPen(pen)
        r_hand = radius * 0.78
        p.drawLine(
            int(center.x()), int(center.y()),
            int(center.x() + r_hand * math.cos(sec_ang)),
            int(center.y() + r_hand * math.sin(sec_ang)),
        )

        # texto central: hora e data
        p.setPen(QColor(palette.text))
        font = QFont(DISPLAY_FONT, int(radius * 0.16))
        p.setFont(font)
        time_rect = QRectF(center.x() - radius * 0.5, center.y() - radius * 0.14,
                            radius, radius * 0.28)
        p.drawText(time_rect, Qt.AlignCenter, now.strftime("%H:%M:%S"))

        font2 = QFont(MONO_FONT, max(8, int(radius * 0.075)))
        p.setFont(font2)
        date_color = QColor(palette.text_dim)
        p.setPen(date_color)
        date_rect = QRectF(center.x() - radius * 0.5, center.y() + radius * 0.08,
                            radius, radius * 0.18)
        p.drawText(date_rect, Qt.AlignCenter, now.strftime("%d/%m/%Y"))

        brand_rect = QRectF(center.x() - radius * 0.5, center.y() + radius * 0.22,
                             radius, radius * 0.14)
        p.setPen(QColor(active_color))
        font3 = QFont(MONO_FONT, max(7, int(radius * 0.055)))
        p.setFont(font3)
        p.drawText(brand_rect, Qt.AlignCenter, "J.A.R.V.I.S.")

        p.end()
