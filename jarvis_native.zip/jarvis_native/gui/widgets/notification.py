from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from gui.theme import PALETTES


class NotificationOverlay(QWidget):
    """Empilha toasts no canto superior direito da janela, cada um
    desaparecendo por conta própria depois de alguns segundos."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self._theme = "cyan"
        self.layout_ = QVBoxLayout(self)
        self.layout_.setAlignment(Qt.AlignTop | Qt.AlignRight)
        self.layout_.setContentsMargins(0, 12, 12, 0)
        self.raise_()

    def set_theme(self, theme_name: str):
        self._theme = theme_name if theme_name in PALETTES else "cyan"

    def notify(self, text: str, level: str = "info"):
        palette = PALETTES[self._theme]
        color = palette.warn if level == "warning" else palette.cyan
        label = QLabel(text)
        label.setStyleSheet(
            f"background-color: rgba(4,12,17,235); color: {color}; "
            f"border: 1px solid {color}; padding: 6px 10px; font-size: 11px;"
        )
        label.setMaximumWidth(280)
        label.setWordWrap(True)
        self.layout_.addWidget(label)
        QTimer.singleShot(4500, lambda: self._remove(label))

    def _remove(self, label: QLabel):
        self.layout_.removeWidget(label)
        label.deleteLater()

    def resizeEvent(self, event):
        if self.parent():
            self.setGeometry(self.parent().rect())
        super().resizeEvent(event)
