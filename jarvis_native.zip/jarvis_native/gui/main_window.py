"""
Janela principal do JARVIS nativo.

Isto substitui jarvis-hud.html + style.css + main.js. A janela se
inscreve em `ui_bridge.subscribe(...)` e recebe os mesmos tipos de
evento que antes iam para o navegador via websocket; cada tipo é
tratado num método `_on_<tipo>`, o equivalente direto de cada `case`
do switch em main.js.

Escopo desta primeira versão (ver README para o plano completo):
  - Feito: terminal/chat, logs, status/uptime, tema, mic toggle,
    notificações, clima e notícias (cards simples), preview de
    screenshot do navegador.
  - Pendente (ver README): quadro de raciocínio (grafo de nós) e
    simulação física animada — por ora só aparecem como uma linha
    de log, em vez do diagrama SVG animado original.
"""

import time

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QFrame, QPushButton, QSizePolicy, QScrollArea,
)

from gui.theme import PALETTES, build_qss
from gui.widgets.clock_widget import ClockRadarWidget
from gui.widgets.terminal_panel import TerminalPanel
from gui.widgets.logs_panel import LogsPanel
from gui.widgets.cmd_bar import CmdBar
from gui.widgets.notification import NotificationOverlay

import tools.ui_bridge as ui_bridge


class TopBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("TopBar")
        self._start_time = time.time()

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 6, 12, 6)

        brand = QLabel("JARVIS OS v1.0")
        brand.setProperty("role", "brand")
        layout.addWidget(brand)
        layout.addSpacing(16)

        layout.addWidget(QLabel("USER:"))
        self.user_value = QLabel("OPERADOR")
        self.user_value.setProperty("role", "value")
        layout.addWidget(self.user_value)
        layout.addSpacing(16)

        layout.addWidget(QLabel("STATUS:"))
        self.status_value = QLabel("ONLINE")
        self.status_value.setProperty("role", "ok")
        layout.addWidget(self.status_value)
        layout.addSpacing(16)

        layout.addWidget(QLabel("UPTIME:"))
        self.uptime_value = QLabel("00:00:00")
        self.uptime_value.setProperty("role", "value")
        layout.addWidget(self.uptime_value)

        layout.addStretch(1)

        self.status_pill = QLabel("SISTEMA ONLINE")
        self.status_pill.setProperty("role", "ok")
        layout.addWidget(self.status_pill)

        self.settings_btn = QPushButton("⚙")
        self.settings_btn.setFixedSize(26, 26)
        layout.addWidget(self.settings_btn)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)

    def _tick(self):
        elapsed = int(time.time() - self._start_time)
        h, rem = divmod(elapsed, 3600)
        m, s = divmod(rem, 60)
        self.uptime_value.setText(f"{h:02d}:{m:02d}:{s:02d}")

    def set_status(self, state: str):
        labels = {
            "idle": "ONLINE", "thinking": "PROCESSANDO",
            "speaking": "FALANDO", "offline": "OFFLINE",
        }
        text = labels.get(state, state.upper())
        self.status_value.setText(text)
        self.status_value.setProperty("role", "offline" if state == "offline" else "ok")
        self.style().unpolish(self.status_value)
        self.style().polish(self.status_value)
        self.status_pill.setText(f"SISTEMA {text}")


class SettingsDrawer(QFrame):
    theme_changed = None  # setado externamente para um Signal-like callback

    def __init__(self, on_theme_change, parent=None):
        super().__init__(parent)
        self.setObjectName("SettingsDrawer")
        self.setFixedWidth(200)
        self.hide()
        self._on_theme_change = on_theme_change

        layout = QVBoxLayout(self)
        title = QLabel("TEMA")
        layout.addWidget(title)

        swatches = QHBoxLayout()
        for name in PALETTES:
            btn = QPushButton()
            btn.setFixedSize(22, 22)
            btn.setStyleSheet(
                f"background-color: {PALETTES[name].cyan}; border-radius: 11px;"
            )
            btn.clicked.connect(lambda _c, n=name: self._on_theme_change(n))
            swatches.addWidget(btn)
        layout.addLayout(swatches)
        layout.addStretch(1)


class WeatherCard(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self.hide()
        layout = QVBoxLayout(self)
        header = QHBoxLayout()
        self.title = QLabel("Clima")
        self.title.setProperty("role", "panel-title")
        header.addWidget(self.title, 1)
        close_btn = QPushButton("FECHAR")
        close_btn.clicked.connect(self.hide)
        header.addWidget(close_btn)
        layout.addLayout(header)
        self.body = QLabel("--")
        self.body.setWordWrap(True)
        layout.addWidget(self.body)

    def show_weather(self, dados: dict):
        local = dados.get("local", "Clima")
        temp = dados.get("temp", "--")
        condicao = dados.get("condicao", "—")
        sensacao = dados.get("sensacao", "--")
        umidade = dados.get("umidade", "--")
        vento = dados.get("vento", "--")
        self.title.setText(local)
        self.body.setText(
            f"{temp}°C — {condicao}\n"
            f"Sensação: {sensacao}°C   Umidade: {umidade}%   Vento: {vento} km/h"
        )
        self.show()


class NewsCard(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self.hide()
        layout = QVBoxLayout(self)
        header = QHBoxLayout()
        self.title = QLabel("Notícias")
        self.title.setProperty("role", "panel-title")
        header.addWidget(self.title, 1)
        close_btn = QPushButton("FECHAR")
        close_btn.clicked.connect(self.hide)
        header.addWidget(close_btn)
        layout.addLayout(header)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.list_widget = QWidget()
        self.list_layout = QVBoxLayout(self.list_widget)
        scroll.setWidget(self.list_widget)
        layout.addWidget(scroll)

    def show_news(self, titulo: str, itens: list):
        self.title.setText(titulo or "Notícias")
        while self.list_layout.count():
            child = self.list_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        for item in itens or []:
            texto = item.get("titulo") or item.get("title") or str(item)
            lbl = QLabel(f"• {texto}")
            lbl.setWordWrap(True)
            self.list_layout.addWidget(lbl)
        self.list_layout.addStretch(1)
        self.show()


class BrowserPreview(QFrame):
    """Mostra o screenshot enviado pelo web_agent — não é um navegador
    embutido, é a mesma técnica de 'foto da tela' usada no HUD web
    original (evento browser_screenshot)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self.hide()
        layout = QVBoxLayout(self)
        header = QHBoxLayout()
        self.title = QLabel("Navegação")
        self.title.setProperty("role", "panel-title")
        header.addWidget(self.title, 1)
        close_btn = QPushButton("FECHAR")
        close_btn.clicked.connect(self.hide)
        header.addWidget(close_btn)
        layout.addLayout(header)
        self.image_label = QLabel()
        self.image_label.setScaledContents(True)
        self.image_label.setMinimumSize(320, 200)
        layout.addWidget(self.image_label)

    def update_screenshot(self, titulo: str, url: str, imagem_base64: str):
        self.title.setText(f"{titulo or '—'} · {url or ''}")
        if imagem_base64:
            pix = QPixmap()
            import base64
            pix.loadFromData(base64.b64decode(imagem_base64))
            self.image_label.setPixmap(pix)
        self.show()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("J.A.R.V.I.S.")
        self.resize(1280, 800)

        self._theme = "cyan"

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        self.topbar = TopBar()
        self.topbar.settings_btn.clicked.connect(self._toggle_settings)
        root.addWidget(self.topbar)

        main_area = QGridLayout()
        root.addLayout(main_area, 1)

        clock_col = QVBoxLayout()
        self.clock = ClockRadarWidget()
        clock_col.addWidget(self.clock, 1)
        self.weather_card = WeatherCard()
        clock_col.addWidget(self.weather_card)
        self.news_card = NewsCard()
        clock_col.addWidget(self.news_card)
        self.browser_preview = BrowserPreview()
        clock_col.addWidget(self.browser_preview)
        main_area.addLayout(clock_col, 0, 0)

        self.terminal = TerminalPanel()
        main_area.addWidget(self.terminal, 0, 1)

        self.logs = LogsPanel()
        main_area.addWidget(self.logs, 0, 2)

        main_area.setColumnStretch(0, 3)
        main_area.setColumnStretch(1, 5)
        main_area.setColumnStretch(2, 3)

        self.cmd_bar = CmdBar()
        self.cmd_bar.message_sent.connect(self._on_message_sent)
        self.cmd_bar.mic_toggled.connect(self._on_mic_toggled)
        root.addWidget(self.cmd_bar)

        self.settings_drawer = SettingsDrawer(self._apply_theme, parent=central)
        self.settings_drawer.move(self.width() - 220, 46)

        self.notifications = NotificationOverlay(parent=central)
        self.notifications.setGeometry(central.rect())

        self._apply_theme("cyan")

        ui_bridge.subscribe(self.handle_broadcast)

    # ---- ações do usuário -> backend -------------------------------
    def _on_message_sent(self, text: str):
        self.terminal.add_line("user", text)
        ui_bridge.mensagens_entrada.put(text)

    def _on_mic_toggled(self, ativo: bool):
        ui_bridge.acoes_entrada.put({"action": "mic_toggle", "ativo": ativo})

    def _toggle_settings(self):
        self.settings_drawer.setVisible(not self.settings_drawer.isVisible())

    def _apply_theme(self, name: str):
        self._theme = name
        self.setStyleSheet(build_qss(PALETTES[name]))
        self.clock.set_theme(name)
        self.terminal.set_theme(name)
        self.logs.set_theme(name)
        self.notifications.set_theme(name)

    # ---- eventos do backend -> UI (equivalente ao switch do main.js) --
    # Dispatcher genérico: cada `type` do payload vira `_on_<type>`.
    # Renomeado para `handle_broadcast` (em vez de `_on_event`) porque
    # o próprio backend também manda um `type: "event"` — que teria
    # colidido com o nome deste método.
    def handle_broadcast(self, evento: dict):
        tipo = evento.get("type")
        handler = getattr(self, f"_on_{tipo}", None)
        if handler:
            handler(evento)

    def _on_log(self, evento):
        self.terminal.add_line(evento.get("role", "system"), evento.get("text", ""))

    def _on_status(self, evento):
        state = evento.get("state", "idle")
        self.topbar.set_status(state)
        self.clock.set_state(state)

    def _on_event(self, evento):
        # payload: {"type": "event", "level": ..., "text": ...}
        self.logs.add_event(evento.get("level", "info"), evento.get("text", ""))

    def _on_memory(self, evento):
        self.logs.add_event("info", "Memória atualizada")

    def _on_mic_state(self, evento):
        ativo = evento.get("ativo", True)
        self.cmd_bar.set_mic_state(ativo)
        self.logs.add_event("info", "Microfone ativado" if ativo else "Microfone desativado")

    def _on_voice_stats(self, evento):
        self.logs.add_event("info", "Atividade de voz")

    def _on_notification(self, evento):
        self.notifications.notify(evento.get("text", ""), evento.get("level", "info"))

    def _on_tool_exec(self, evento):
        status = evento.get("status", "em curso")
        nome = evento.get("name", "?")
        self.logs.add_event("error" if status == "error" else "info", f"{nome}: {status}")
        if status == "error":
            self.notifications.notify(f'Falha na ferramenta "{nome}"', "warning")

    def _on_tool_result(self, evento):
        nome = evento.get("name", "?")
        sucesso = evento.get("success", True)
        resultado = evento.get("message") or evento.get("result") or ""
        self.terminal.add_line("system", f"[{nome}] {resultado}")
        self.logs.add_event("error" if not sucesso else "info", f"{nome} concluída")

    def _on_weather(self, evento):
        self.weather_card.show_weather(evento)

    def _on_news_board(self, evento):
        self.news_card.show_news(evento.get("titulo", ""), evento.get("news", []))

    def _on_browser_screenshot(self, evento):
        self.browser_preview.update_screenshot(
            evento.get("titulo", ""), evento.get("url", ""), evento.get("imagem_base64", "")
        )

    def _on_browser_navigate(self, evento):
        # Sem navegador embutido no app nativo: registramos e avisamos.
        self.logs.add_event("info", f"Navegação: {evento.get('titulo') or evento.get('url')}")

    def _on_reasoning_board(self, evento):
        self.logs.add_event("info", f"Quadro de raciocínio: {evento.get('titulo', '')} (diagrama ainda não portado)")

    def _on_reasoning_frame(self, evento):
        pass  # ver README — diagrama de nós ainda não portado

    def _on_simulation_board(self, evento):
        self.logs.add_event("info", f"Simulação: {evento.get('titulo', '')} (ainda não portada)")

    def _on_simulation_scene(self, evento):
        pass

    def _on_simulation_frame(self, evento):
        pass

    def _on_subsystem(self, evento):
        pass  # decorativo no original; sem equivalente visual por ora

    def _on_timeline(self, evento):
        pass  # não era consumido pela UI web original

    def _on_timeline_add(self, evento):
        pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.settings_drawer.move(self.width() - 220, 46)
        self.notifications.setGeometry(self.centralWidget().rect())
