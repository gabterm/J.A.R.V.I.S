"""
STUB — substitua este arquivo pelo `tools/voice.py` original do seu
projeto (o que faz TTS de verdade). Isto aqui só existe para o app
rodar em modo demo sem quebrar o import.
"""

import re

_SENTENCE_END = re.compile(r"([.!?])(\s|$)")


def speak(texto: str):
    print(f"[voice STUB] falaria: {texto}")


def limpar_para_fala(texto: str) -> str:
    return texto.strip()


def extrair_proxima_frase(buffer: str):
    match = _SENTENCE_END.search(buffer)
    if not match:
        return None, buffer
    fim = match.end()
    return buffer[:fim].strip(), buffer[fim:]
