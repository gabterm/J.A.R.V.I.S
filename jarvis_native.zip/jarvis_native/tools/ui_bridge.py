"""
Substituto nativo do antigo `ui_bridge` (que rodava um servidor
websocket para servir o HUD em HTML/CSS/JS).

Agora a UI é uma janela Qt no MESMO processo, então não existe mais
"servidor" nem "clientes conectados" — só um sinal Qt (`broadcast`)
que a MainWindow escuta, e duas Queues que a MainWindow alimenta
quando o usuário digita algo ou clica em pin/unpin/remove.

A API pública é intencionalmente idêntica à versão antiga para que
`main.py` e `tools/tools.py` não precisem ser alterados:

    ui_bridge.broadcast({...})
    ui_bridge.mensagens_entrada.put(texto)
    ui_bridge.acoes_entrada.put({...})
    ui_bridge.jarvis_falando.set() / .clear() / .is_set()
    ui_bridge.start_server_in_background()

A única API nova é `subscribe(slot)`, usada pela MainWindow para
receber os eventos.
"""

import threading
from queue import Queue

from PySide6.QtCore import QObject, Signal


class _Bridge(QObject):
    # Emitido para todo `broadcast(payload)`. Qt entrega isso com
    # fila (queued connection) quando quem emite está numa thread
    # diferente da GUI, então é seguro chamar de qualquer lugar.
    event = Signal(dict)


_bridge = _Bridge()

# Filas consumidas pelo loop principal em main.py — continuam sendo
# filas de verdade, só que agora quem produz é a própria janela Qt
# (input de texto, mic, ações da timeline) em vez de um handler HTTP.
mensagens_entrada: "Queue[str]" = Queue()
acoes_entrada: "Queue[dict]" = Queue()

# Mesma semântica de antes: fica "set" enquanto o TTS está falando.
jarvis_falando = threading.Event()


def broadcast(payload: dict) -> None:
    """Envia um evento para a UI. Substitui o antigo `ws.send(json)`."""
    _bridge.event.emit(payload)


def subscribe(slot) -> None:
    """Usado pela MainWindow para receber todo evento de `broadcast`."""
    _bridge.event.connect(slot)


def start_server_in_background() -> None:
    """
    No modo web antigo, isso subia o servidor HTTP/WS.
    No app nativo a janela já está de pé antes do backend iniciar,
    então não há nada para subir — mantido só para compatibilidade
    de chamada com main.py.
    """
    return None
