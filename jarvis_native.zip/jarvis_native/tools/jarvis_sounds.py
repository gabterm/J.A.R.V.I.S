"""
STUB — substitua pelo `tools/jarvis_sounds.py` original do seu
projeto. Aqui só existe pra não quebrar o import em modo demo.
"""


class _Sounds:
    def play(self, nome: str, block: bool = False):
        print(f"[sounds STUB] tocaria: {nome}")


sounds = _Sounds()
