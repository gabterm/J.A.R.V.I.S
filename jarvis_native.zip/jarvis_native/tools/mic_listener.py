"""
STUB — substitua pelo `tools/mic_listener.py` original do seu
projeto (o que faz STT/wake-word de verdade).
"""

import time


def escutar_microfone():
    while True:
        time.sleep(3600)
