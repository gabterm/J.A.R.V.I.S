"""
STUB — substitua pelo `tools/web_agent.py` original do seu projeto
(sessão de navegador via Playwright, screenshots ao vivo, etc).
"""

_MSG = "web_agent STUB — não implementado"


def browser_open(url):
    return {"success": False, "message": _MSG}


def browser_click(alvo):
    return {"success": False, "message": _MSG}


def browser_type(alvo, texto, enter=False):
    return {"success": False, "message": _MSG}


def browser_scroll(direcao, quantidade=1):
    return {"success": False, "message": _MSG}


def browser_back():
    return {"success": False, "message": _MSG}


def browser_forward():
    return {"success": False, "message": _MSG}


def browser_read():
    return {"success": False, "message": _MSG}


def browser_close():
    return {"success": False, "message": _MSG}
