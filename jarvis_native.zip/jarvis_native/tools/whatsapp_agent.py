"""
STUB — substitua pelo `tools/whatsapp_agent.py` original do seu
projeto (sessão persistente via Playwright).
"""


def start_whatsapp_session():
    pass


def list_unread_whatsapp():
    return {"success": False, "message": "whatsapp_agent STUB — não implementado"}


def read_whatsapp_chat(contato, quantidade=10):
    return {"success": False, "message": "whatsapp_agent STUB — não implementado"}


def send_whatsapp_message(contato, texto, confirmado=False):
    return {"success": False, "message": "whatsapp_agent STUB — não implementado"}
