"""
Novo ponto de entrada do JARVIS, no lugar de `python main.py` +
navegador. A lógica de negócio (memória, extração de fatos, loop de
tool calling em main.py, e as ferramentas em tools/tools.py) continua
100% igual — só troca quem desenha a UI e quem entrega mensagens
entre os dois lados (agora é `tools/ui_bridge.py`, baseado em sinais
Qt, no lugar do servidor websocket).

Uso:
    pip install -r requirements.txt
    python run_native.py
"""

import sys
import threading

from PySide6.QtWidgets import QApplication

from gui.main_window import MainWindow

import main as jarvis_core  # o main.py original, sem nenhuma mudança de lógica


def _run_backend():
    """Roda o loop principal do JARVIS (main.py) numa thread separada
    da GUI. Toda comunicação passa por tools/ui_bridge.py, que é
    thread-safe (sinais Qt em fila) — a GUI nunca é tocada
    diretamente por essa thread."""
    jarvis_core.main()


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()

    backend_thread = threading.Thread(target=_run_backend, daemon=True)
    backend_thread.start()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
